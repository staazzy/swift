import UIKit

enum engine: String {
    case on = "двигатель заведён"
    case off = "двигатель заглушён"
}

enum windows: String {
    case open = "окна открыты"
    case close = "окна закрыты"
}

enum body: String {
    case full = "все места заняты"
    case empty = "места свободны"
    case driver = "только водитель"
    case passengers = "есть пассажиры"
}

struct lightWeightCar {
    var brand: String
    var year: Int
    var body: body
    var engine: engine
    var windows: windows
    var trunk: Double
    
    mutating func ignition(action: engine) {
        switch action {
        case .on:
            print(action.rawValue)
            self.engine = .on
        case .off:
            print(action.rawValue)
            self.engine = .off
        }
    }
    mutating func landing(action: body) {
        switch action {
        case .full:
            print(action.rawValue)
            self.body = .full
        case .empty:
            print(action.rawValue)
            self.body = .empty
        case .driver:
            print(action.rawValue)
            self.body = .driver
        case .passengers:
            print(action.rawValue)
            self.body = .passengers
        
        }
    }
    func description(){
        print("Автомобиль \(brand), \(year) года выпуска. Сейчас: \(engine.rawValue). В автотранспорте: \(body.rawValue).")
    }
}

var car1 = lightWeightCar(brand: "Porsche", year: 2008, body: .driver, engine: .off, windows: .close, trunk: 30)

car1.description()
car1.ignition(action: .on)
car1.landing(action: .full)
car1.description()

var car2 = lightWeightCar(brand: "Lada", year: 2021, body: .empty, engine: .off, windows: .close, trunk: 150)

car2.description()
car2.windows
car2.trunk

struct Truck {
    var brand: String
    var year: Int
    var body: body
    var engine: engine
    var windows: windows
    var trunk: Double
    
    mutating func ignition(action: engine) {
        switch action {
        case .on:
            print(action.rawValue)
            self.engine = .on
        case .off:
            print(action.rawValue)
            self.engine = .off
        }
    }
    mutating func landing(action: body) {
        switch action {
        case .full:
            print(action.rawValue)
            self.body = .full
        case .empty:
            print(action.rawValue)
            self.body = .empty
        case .driver:
            print(action.rawValue)
            self.body = .driver
        case .passengers:
            print(action.rawValue)
            self.body = .passengers
        
        }
    }
    func description(){
        print("Грузовик \(brand), \(year) года выпуска. Сейчас: \(engine.rawValue). В автотранспорте: \(body.rawValue). Грузоподъёмность: \(trunk).")
    }
}

var truck1 = Truck(brand: "Kamaz", year: 2010, body: .driver, engine: .off, windows: .close, trunk: 2500)

truck1.description()
